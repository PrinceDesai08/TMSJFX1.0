package main.util.builder;

import main.view.PropertyView;

public class PropertyViewModelBuilder {
    public PropertyView build() {
    	return new PropertyView();
    }
}
