package main.util.builder;

import main.model.RentModel;

public class RentModelBuilder {
    public RentModel build() {
    	return new RentModel();
    }
}
