package main.util.builder;

import main.model.LeaseModel;

public class LeaseModelBuilder {
   public LeaseModel build() {
	   return new LeaseModel();
   }
}
