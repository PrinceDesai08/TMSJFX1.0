package main.util.builder;

import main.model.PropertyModel;

public class PropertyModelBuilder {
   public PropertyModel build() {
	   return new PropertyModel();
   }
}
