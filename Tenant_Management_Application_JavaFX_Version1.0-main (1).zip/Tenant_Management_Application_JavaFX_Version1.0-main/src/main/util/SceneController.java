package main.util;

import javafx.stage.Stage;
import java.util.HashMap;
import javafx.scene.Scene;

public class SceneController {
	static Stage stage;
    public static HashMap<String, Scene> scenes = new HashMap<>();
    
    public SceneController() {
    	
    }
    public SceneController(Stage stage) {
    	SceneController.stage = stage;
    }
    
    public void addScene(String name, Scene scene) {
        scenes.put(name, scene);
    }

    public void switchToScene(String name) {
    	
        Scene scene = scenes.get(name);
        if (scene == null) {
            throw new IllegalArgumentException("Scene '" + name + "' does not exist");
        }
        stage.setScene(scene);
        stage.setTitle("Tenant Management Application");
        stage.setMaximized(true);
        stage.show();
    }
 
}

