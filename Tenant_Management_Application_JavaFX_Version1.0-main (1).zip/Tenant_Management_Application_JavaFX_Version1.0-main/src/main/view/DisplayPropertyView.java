package main.view;

import java.util.LinkedHashMap;
import java.util.Map;

import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import main.controller.PropertyController;
import main.model.ApartmentModel;
import main.model.CondoModel;
import main.model.HouseModel;
import main.model.PropertyModel;
import main.util.SceneController;
import main.util.builder.PropertyModelBuilder;
import main.util.builder.PropertyViewModelBuilder;

public class DisplayPropertyView {
	// Property Vacany Flag
	boolean propertyVacancyStatusFlag = false;

	// Creating SceneController Class Object
	SceneController sceneCtrl = new SceneController();

	// Property Dummy Data
	static LinkedHashMap<Integer, PropertyModel> propertyList =  new LinkedHashMap<Integer, PropertyModel>();

	// Load Property Data
	void setPropertyData() {
		PropertyModelBuilder pBuilder = new PropertyModelBuilder();
		PropertyViewModelBuilder pViewBuilder = new PropertyViewModelBuilder();
		PropertyModel pModel = pBuilder.build();
		PropertyView pView = pViewBuilder.build();
		PropertyController pController = new PropertyController(pModel, pView);
		DisplayPropertyView.propertyList = pController.displayPropertyController();
	}
	
	public void loadUI() {
		if (propertyList.size()==0) {
			Text propertyVacancyStatusMessgae = new Text("Sorry, there are no properties in the system");
			FlowPane fPane = new FlowPane();
			FlowPane.setMargin(propertyVacancyStatusMessgae, new Insets(100));
			fPane.setAlignment(Pos.TOP_CENTER);
			fPane.getChildren().add(propertyVacancyStatusMessgae);
			Scene displayPropertyScene = new Scene(fPane);
			sceneCtrl.addScene("Display Property", displayPropertyScene);
			sceneCtrl.switchToScene("Display Property");
		} else {
			int row = 0, col = 0, i;
			Text propertyDisplayMessage = new Text("List of properties are:");
			GridPane root = new GridPane();
			ScrollPane scrollPane = new ScrollPane(root);
			scrollPane.setFitToWidth(true);
			scrollPane.setFitToHeight(true);
			root.setAlignment(Pos.CENTER);
			root.setHgap(15);
	
			for (Map.Entry<Integer, PropertyModel> entry : propertyList.entrySet()) {
			    int key = entry.getKey();
			    PropertyModel property = entry.getValue();
			    BorderPane card = new BorderPane();
				card.setPadding(new Insets(10));
				card.setStyle("-fx-background-color: #576CBC; -fx-background-radius: 10px;");

				FlowPane fPane = new FlowPane();
				if(property.getPropertyType().equalsIgnoreCase("Apartment")) {
				Text propertyID = new Text("PropertyID: " + String.valueOf(property.getPropertyID()));
				Text typeOfProperty = new Text("Property Type: " + property.getPropertyType());
				Text propertyVacanyStatus = new Text("Property Vacany Status: "
						+ (property.getVacancy() ? "Property is Vacant" : "Property is not Vacant"));
				Text propertyNumber = new Text(
						"Apartment Number: " + ((ApartmentModel) property).getApartmentNumber());
				Text propertyCivicNumber = new Text(
						"Apartment Civic Number: " + ((ApartmentModel) property).getCivicAddress());
				Text propertyStreet = new Text("Street is: " + property.getStreetName());
				Text propertyCity = new Text("City is: " + property.getCity());
				Text properyProvince = new Text("Province is: " + property.getProvince());
				Text propertyCountry = new Text("Country is: " + property.getCountry());
				Text propertyPostalCode = new Text("Postal Code is: " + property.getPostalCode());
				Text propertyBedroomCount = new Text(
						"Number of Bedrooms: " + ((ApartmentModel) property).getNumberOfBedRooms());
				Text propertyBathromCount = new Text(
						"Number of Bathrooms: " + ((ApartmentModel) property).getNumberOfBathrooms());
				Text propertySquareFootage = new Text(
						"Size of Apartment: " + ((ApartmentModel) property).getSquareFootage());
				Text propertyRent = new Text("Rent is: " + property.getRent());
				Text renovationNeeded = new Text("Renovation needed for the property: "
						+ (property.getRenovationUpdateStatus() ? "Yes" : "No"));
				fPane.getChildren().addAll(propertyID, typeOfProperty, propertyVacanyStatus, propertyNumber,
						propertyCivicNumber, propertyStreet, propertyCity, properyProvince, propertyCountry,
						propertyPostalCode, propertyBedroomCount, propertyBathromCount, propertySquareFootage,
						propertyRent, renovationNeeded);
				}
				else if(property.getPropertyType().equalsIgnoreCase("Condo")) {
					Text propertyID = new Text("PropertyID: " + String.valueOf(property.getPropertyID()));
					Text typeOfProperty = new Text("Property Type: " + property.getPropertyType());
					Text propertyVacanyStatus = new Text("Property Vacany Status: "
							+ (property.getVacancy() ? "Property is Vacant" : "Property is not Vacant"));
					Text propertyNumber = new Text(
							"Condo Unit Number: " + ((CondoModel) property).getUnitNumber());
					Text propertyCivicNumber = new Text(
							"Condo Street Number: " + ((CondoModel) property).getStreetNumber());
					Text propertyStreet = new Text("Street is: " + property.getStreetName());
					Text propertyCity = new Text("City is: " + property.getCity());
					Text properyProvince = new Text("Province is: " + property.getProvince());
					Text propertyCountry = new Text("Country is: " + property.getCountry());
					Text propertyPostalCode = new Text("Postal Code is: " + property.getPostalCode());
					Text propertyRent = new Text("Rent is: " + property.getRent());
					Text renovationNeeded = new Text("Renovation needed for the property: "
							+ (property.getRenovationUpdateStatus() ? "Yes" : "No"));
					fPane.getChildren().addAll(propertyID, typeOfProperty, propertyVacanyStatus, propertyNumber,
							propertyCivicNumber, propertyStreet, propertyCity, properyProvince, propertyCountry,
							propertyPostalCode,
							propertyRent, renovationNeeded);
				}
				else if(property.getPropertyType().equalsIgnoreCase("House")) {
					Text propertyID = new Text("PropertyID: " + String.valueOf(property.getPropertyID()));
					Text typeOfProperty = new Text("Property Type: " + property.getPropertyType());
					Text propertyVacanyStatus = new Text("Property Vacany Status: "
							+ (property.getVacancy() ? "Property is Vacant" : "Property is not Vacant"));
					
					Text propertyCivicNumber = new Text(
							"Condo Street Number: " + ((HouseModel) property).getStreetNumber());
					Text propertyStreet = new Text("Street is: " + property.getStreetName());
					Text propertyCity = new Text("City is: " + property.getCity());
					Text properyProvince = new Text("Province is: " + property.getProvince());
					Text propertyCountry = new Text("Country is: " + property.getCountry());
					Text propertyPostalCode = new Text("Postal Code is: " + property.getPostalCode());
					Text propertyRent = new Text("Rent is: " + property.getRent());
					Text renovationNeeded = new Text("Renovation needed for the property: "
							+ (property.getRenovationUpdateStatus() ? "Yes" : "No"));
					fPane.getChildren().addAll(propertyID, typeOfProperty, propertyVacanyStatus,
							propertyCivicNumber, propertyStreet, propertyCity, properyProvince, propertyCountry,
							propertyPostalCode,
							propertyRent, renovationNeeded);
				}
				
				fPane.setMinHeight(300);
				fPane.setMaxHeight(300);
				fPane.setMinWidth(300);
				fPane.setMaxWidth(300);
				fPane.setOrientation(Orientation.VERTICAL);
				card.setCenter(fPane);
				GridPane.setMargin(card, new Insets(20));
				root.add(card, col, row);
			
				++col;
				if (col == 4) {
					col = 0;
					++row;
				}
			}


			
//			for (i = 0; i < pModel.length; i++) {
//				BorderPane card = new BorderPane();
//				card.setPadding(new Insets(10));
//				card.setStyle("-fx-background-color: #576CBC; -fx-background-radius: 10px;");
//
//				FlowPane fPane = new FlowPane();
//				Text propertyID = new Text("PropertyID: " + String.valueOf(pModel[i].getPropertyID()));
//				Text typeOfProperty = new Text("Property Type: " + pModel[i].getPropertyType());
//				Text propertyVacanyStatus = new Text("Property Vacany Status: "
//						+ (pModel[i].getVacancy() ? "Property is Vacant" : "Property is not Vacant"));
//				Text propertyNumber = new Text(
//						"Apartment Number: " + ((ApartmentModel) pModel[i]).getApartmentNumber());
//				Text propertyCivicNumber = new Text(
//						"Apartment Civic Number: " + ((ApartmentModel) pModel[i]).getCivicAddress());
//				Text propertyStreet = new Text("Street is: " + pModel[i].getStreetName());
//				Text propertyCity = new Text("City is: " + pModel[i].getCity());
//				Text properyProvince = new Text("Province is: " + pModel[i].getProvince());
//				Text propertyCountry = new Text("Country is: " + pModel[i].getCountry());
//				Text propertyPostalCode = new Text("Postal Code is: " + pModel[i].getPostalCode());
//				Text propertyBedroomCount = new Text(
//						"Number of Bedrooms: " + ((ApartmentModel) pModel[i]).getNumberOfBedRooms());
//				Text propertyBathromCount = new Text(
//						"Number of Bathrooms: " + ((ApartmentModel) pModel[i]).getNumberOfBathrooms());
//				Text propertySquareFootage = new Text(
//						"Size of Apartment: " + ((ApartmentModel) pModel[i]).getSquareFootage());
//				Text propertyRent = new Text("Rent is: " + pModel[i].getRent());
//				Text renovationNeeded = new Text("Renovation needed for the property: "
//						+ (pModel[i].getRenovationUpdateStatus() ? "Yes" : "No"));
//				fPane.getChildren().addAll(propertyID, typeOfProperty, propertyVacanyStatus, propertyNumber,
//						propertyCivicNumber, propertyStreet, propertyCity, properyProvince, propertyCountry,
//						propertyPostalCode, propertyBedroomCount, propertyBathromCount, propertySquareFootage,
//						propertyRent, renovationNeeded);
//				fPane.setMinHeight(300);
//				fPane.setMaxHeight(500);
//				fPane.setOrientation(Orientation.VERTICAL);
//				card.setCenter(fPane);
//				GridPane.setMargin(card, new Insets(20));
//				root.add(card, col, row);
//			
//				++col;
//				if (col == 4) {
//					col = 0;
//					++row;
//				}
//
//			}
			Scene displayPropertyScene = new Scene(scrollPane);
			sceneCtrl.addScene("Display Property", displayPropertyScene);
			sceneCtrl.switchToScene("Display Property");
		}
	}
}
