package main.view;


import java.util.Optional;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import main.controller.PropertyController;
import main.model.PropertyModel;
import main.util.SceneController;
import main.util.builder.PropertyModelBuilder;
import main.util.builder.PropertyViewModelBuilder;

public class CancelLeaseView {
	// Creating SceneController Class Object
	SceneController sceneCtrl = new SceneController();

	// Update Lease View Flag
	boolean updateLeaseViewFlag = false, submitBtnFlag = false;
	static boolean renovationStatusAddedFlag = false, renovationResultFlag = false;

	Text propertyNotPresentText = null;
	public static int propertyID = -1;

	public void setLeaseViewFlag() {
		this.updateLeaseViewFlag = true;
	}

	// Validating inputs
	public static boolean validateFields(TextField propertIdValue, TextField renovationStatusFlagValue) {
		
		StringBuilder errorList = new StringBuilder();
		if (propertIdValue.getText().trim().isEmpty()) {
			errorList.append("Please enter Property ID\n");
		}
		if (CancelLeaseView.renovationStatusAddedFlag) {
			
			if (renovationStatusFlagValue.getText().trim().isEmpty()) {
				errorList.append("Please enter Renovation needed or not status\n");
			}
		}

		if (errorList.length() > 0) {
			Alert alert = new Alert(Alert.AlertType.WARNING);
			alert.setTitle("Warning");
			alert.setHeaderText("Required Fields Empty");
			alert.setContentText(errorList.toString());

			alert.showAndWait();
			return false;
		}

		// returns true if there is no error
		return true;
	}

	// Checking PropertyID status from DB
	public String checkPropertyIDStatus(int pID) {

		if (CancelLeaseView.propertyID == -1
				|| (CancelLeaseView.propertyID != -1 && CancelLeaseView.propertyID != pID)) {
			CancelLeaseView.propertyID = pID;
			// Building PropertyModel and PropertyView using builder
			PropertyModelBuilder pBuilder = new PropertyModelBuilder();
			PropertyViewModelBuilder pViewBuilder = new PropertyViewModelBuilder();
			PropertyModel pModel = pBuilder.build();
			PropertyView pView = pViewBuilder.build();
			PropertyController pController = new PropertyController(pModel, pView);
			if (pController.getPropertyController(CancelLeaseView.propertyID) == null) {
				return "Not Present";
			} else {
				return "Present";
			}
		} else {
			return "No Check";
		}

	}
	
	

	public void loadUI() {

		// Creating Layout
		VBox root = new VBox();
		// Label titleLabel = new Label("Add Apartment Data");
		GridPane gPane = new GridPane();
		// UI
		TextField renovationStatusFlagValue = new TextField();
		TextField propertIdValue = new TextField();
		Label propertyIDLabel = null;

		

		// Creating Labels
		if (!updateLeaseViewFlag) {
			propertyIDLabel = new Label("Enter Property ID to cancel lease");
		} else if (updateLeaseViewFlag) {
			propertyIDLabel = new Label("Enter Property ID to update lease");
		}
		Label renovationStatusFlagLabel = new Label("Enter Yes for renovation needed or No if renovation not needed");

		//  Listening PropertyID TextField to get data from the user
		propertIdValue.focusedProperty().addListener((observable, oldValue, newValue) -> {
			if (!newValue && (propertIdValue.getText().length() > 0)) {
				String propertyIDStatusResult = this.checkPropertyIDStatus(Integer.parseInt(propertIdValue.getText()));
				if (propertyIDStatusResult.equalsIgnoreCase("Not Present")) {
					gPane.getChildren()
							.removeIf(node -> GridPane.getRowIndex(node) != null && GridPane.getRowIndex(node) >= 1);
					propertyNotPresentText = new Text(
							"Sorry there is no property registered in this ID, try entering a valid Property ID");
					gPane.add(propertyNotPresentText, 0, 1, 3, 1);
					submitBtnFlag = false;
					renovationStatusAddedFlag = false;

				} else if (propertyIDStatusResult.equalsIgnoreCase("Present")) {
					gPane.getChildren()
							.removeIf(node -> GridPane.getRowIndex(node) != null && GridPane.getRowIndex(node) >= 1);

					gPane.addRow(1, renovationStatusFlagLabel, renovationStatusFlagValue);
					submitBtnFlag = true;
					renovationStatusAddedFlag = true;
				}
			}
		});
		
		

		gPane.addRow(0, propertyIDLabel, propertIdValue);

		gPane.setAlignment(Pos.CENTER);
		gPane.setHgap(25);
		gPane.setVgap(10);

		// propertIdValue.setPrefWidth(200);
		// Creating Submit Button
		Button submitBtn = new Button("Submit");

		submitBtn.setOnAction((event) -> {
            if(submitBtnFlag) {
			//boolean validationResult = CancelLeaseView.validateFields(propertIdValue, renovationStatusFlagValue);
			if(!propertIdValue.getText().trim().isEmpty() && !renovationStatusFlagValue.getText().trim().isEmpty()) {
				System.out.println("Came");
				if (renovationStatusFlagValue.getText().trim().equalsIgnoreCase("Yes") || renovationStatusFlagValue.getText().trim().equalsIgnoreCase("Y")) {
					renovationResultFlag = true;
				} else if (renovationStatusFlagValue.getText().trim().equalsIgnoreCase("No")|| renovationStatusFlagValue.getText().trim().equalsIgnoreCase("N")) {
					renovationResultFlag = false;
				}
				// Building PropertyModel and PropertyView using builder
				PropertyModelBuilder pBuilder = new PropertyModelBuilder();
 				PropertyViewModelBuilder pViewBuilder = new PropertyViewModelBuilder();
 				PropertyModel pModel = null;
				PropertyView pView;
			    pModel = pBuilder.build();
				pView = pViewBuilder.build();
				PropertyController pController = new PropertyController(pModel, pView);
				if(this.updateLeaseViewFlag) {
					
					String renovationUpdateResult = pController.updateRenovationStatus(CancelLeaseView.propertyID, renovationResultFlag);
					Alert alert = new Alert(Alert.AlertType.INFORMATION);
					alert.setTitle("Success");
					alert.setHeaderText("Renovation Status Update");
					alert.setContentText(renovationUpdateResult);
					Optional<ButtonType> result = alert.showAndWait();
					 if(result.get() == ButtonType.OK) {
						 CancelLeaseView.propertyID = -1;
						 sceneCtrl.switchToScene("Welcome Screen");
					 }
					     
					else if(result.get() == ButtonType.CANCEL) {
						CancelLeaseView.propertyID = -1;
						sceneCtrl.switchToScene("Welcome Screen");
					}
				}
				else {
					String cancelLeaseResult = pController.cancelLeaseController(CancelLeaseView.propertyID, renovationResultFlag);
					Alert alert = new Alert(Alert.AlertType.INFORMATION);
					alert.setTitle("Success");
					alert.setHeaderText("Lease Cancellation");
					alert.setContentText(cancelLeaseResult);
					Optional<ButtonType> result = alert.showAndWait();
					 if(result.get() == ButtonType.OK) {
						 CancelLeaseView.propertyID = -1;
						 sceneCtrl.switchToScene("Welcome Screen");
					 }
					     
					else if(result.get() == ButtonType.CANCEL) {
						CancelLeaseView.propertyID = -1;
						sceneCtrl.switchToScene("Welcome Screen");
					}
				}
				
				
			}
            }
			
		});

		// Adding components in root layout
		root.getChildren().addAll(gPane, submitBtn);
		root.setAlignment(Pos.TOP_CENTER);
		root.setSpacing(30);

		Scene cancelLeaseScene = new Scene(root);

		// Adding CSS
		cancelLeaseScene.getStylesheets().add("/main/styles/CancelLeaseViewStyle.css");

		// Adding CSS Selectors
		root.getStyleClass().add("root-layout");
		submitBtn.getStyleClass().add("submit-btn");

		sceneCtrl.addScene("Cancel Lease", cancelLeaseScene);
		sceneCtrl.switchToScene("Cancel Lease");

	}
}
