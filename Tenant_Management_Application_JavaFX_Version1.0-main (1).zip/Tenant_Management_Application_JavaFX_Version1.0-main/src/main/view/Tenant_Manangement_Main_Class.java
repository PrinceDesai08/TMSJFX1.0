package main.view;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.application.Application;
import javafx.event.Event;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import main.controller.LeaseController;
import main.controller.PropertyController;
import main.controller.RentController;
import main.controller.TenantController;
import main.controller.WaitlistController;
import main.model.ApartmentModel;
import main.model.CondoModel;
import main.model.HouseModel;
import main.model.LeaseModel;
import main.model.PropertyModel;
import main.model.RentModel;
import main.model.TenantModel;
import main.model.WaitlistModel;
import main.util.SceneController;
import main.util.builder.ApartmentModelBuilder;
import main.util.builder.CondoModelBuilder;
import main.util.builder.HouseModelBuilder;
import main.util.builder.LeaseModelBuilder;
import main.util.builder.LeaseViewModelBuilder;
import main.util.builder.PropertyModelBuilder;
import main.util.builder.PropertyViewModelBuilder;
import main.util.builder.RentModelBuilder;
import main.util.builder.RentViewModelBuilder;
import main.util.builder.TenantModelBuilder;
import main.util.builder.TenantViewBuilder;

public class Tenant_Manangement_Main_Class extends Application {
    
	// method to check date is valid or not
	static String checkDateValidity(String d) {
		try {
			SimpleDateFormat format = new SimpleDateFormat("dd/mm/yyyy");
			format.setLenient(false); // will set the date entered by the user in the format (dd/MM/yyyy)
			Date userEnteredDate = format.parse(d);
			return "Valid";

		} catch (ParseException e) {
			return "Invalid";
		}
	}
	
	// Creating Button Event Listener
	public static void addPropertyButtonClickListener(Event event) {
		AddPropertyView aView = new AddPropertyView();
		aView.loadUI();
	}
	
	public static void rentUnitButtonClickListener(Event event) {
		RentUnitView rView = new RentUnitView();
		rView.loadUI();
	}
	
	public static void cancelLeaseButtonClickListener(Event event) {
		CancelLeaseView cView = new CancelLeaseView();
		cView.loadUI();
	}
	
	public static void updateLeaseButtonClickListener(Event event) {
		CancelLeaseView cView = new CancelLeaseView();
		cView.setLeaseViewFlag();
		cView.loadUI();
	}
	
	public static void displayPropertyButtonClickListener(Event event) {
		DisplayPropertyView dView = new DisplayPropertyView();
		dView.setPropertyData();
		dView.loadUI();
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		
	     // Creating SceneController Class Object
		 SceneController sceneCtrl = new SceneController(primaryStage);
		 FlowPane root = new FlowPane();
		 Label titleLabel = new Label("Welcome to Tenant Management Application");
		 Button addPropertyBtn = new Button("Add Property");
		 Button addTenantBtn = new Button("Add Tenant");
		 Button rentUnitBtn = new Button("Rent Unit");
		 Button displayPropertyBtn = new Button("Display Property");
		 Button displayTenantBtn = new Button("Display Tenant");
		 Button displayRentedUnitsBtn = new Button("Display Rented Units");
		 Button displayVacantUnitsBtn = new Button("Display Vacant Units");
		 Button displayLeasesBtn = new Button("Display All Leases");
		 Button trackLeaseBtn = new Button("Track Leases");
		 Button recordPaymentBtn = new Button("Record Payment");
		 Button trackPaymentBtn = new Button("Track Payment");
		 Button cancelLeaseBtn = new Button("Cancel Lease");
		 Button updateRenovationStatusBtn = new Button("Update Renovation Status");
		 Button exitButton = new Button("Exit");
		 
		 
		 // Invoking button event listeners method
		 addPropertyBtn.setOnAction((event)->{
			 Tenant_Manangement_Main_Class.addPropertyButtonClickListener(event);
		 });
		 
		 rentUnitBtn.setOnAction((event)->{
			 Tenant_Manangement_Main_Class.rentUnitButtonClickListener(event);
		 });
		 
		 cancelLeaseBtn.setOnAction((event)->{
			 Tenant_Manangement_Main_Class.cancelLeaseButtonClickListener(event);
		 });
		 
		 displayPropertyBtn.setOnAction((event)->{
			 Tenant_Manangement_Main_Class.displayPropertyButtonClickListener(event);
		 });
		 
		 updateRenovationStatusBtn.setOnAction((event)->{
			 Tenant_Manangement_Main_Class.updateLeaseButtonClickListener(event);
		 });
		
		 // Creating GridPane
		 GridPane gPaneRoot = new GridPane();
		 gPaneRoot.addRow(0, addPropertyBtn,addTenantBtn,rentUnitBtn);
		 gPaneRoot.addRow(1, displayPropertyBtn, displayTenantBtn,displayRentedUnitsBtn );
		 gPaneRoot.addRow(2, displayVacantUnitsBtn, displayLeasesBtn,trackLeaseBtn );
		 gPaneRoot.addRow(3, recordPaymentBtn, trackPaymentBtn,cancelLeaseBtn );
		 gPaneRoot.addRow(4,updateRenovationStatusBtn, exitButton);
		 gPaneRoot.setHgap(15);
		 gPaneRoot.setVgap(20);
		 gPaneRoot.setAlignment(Pos.CENTER);
//		 root.setTop(titleLabel);
//	     root.setCenter(gPaneRoot);	
	   //  BorderPane.setAlignment(titleLabel, Pos.CENTER);
		 root.getChildren().add(titleLabel);
		 root.getChildren().add(gPaneRoot);
		 root.setOrientation(Orientation.VERTICAL);
		 root.setVgap(60);
		 root.setAlignment(Pos.TOP_CENTER);
	     // Adding class value to apply CSS
	     root.getStyleClass().add("root-layout");
	     titleLabel.getStyleClass().add("application-title");
	     
		 // Creating Scene
		 Scene welcomeScreen = new Scene(root);
		 
		 // Adding CSS File
		 welcomeScreen.getStylesheets().add(getClass().getResource("/main/styles/Tenant_Management_Main_Class_Style.css").toExternalForm());
		 
		 // Invoking Screen
		 sceneCtrl.addScene("Welcome Screen", welcomeScreen);
		 sceneCtrl.switchToScene("Welcome Screen");
		 
		
		 
		
	}

	public static void main(String[] args) {
		launch(args);
	}
//		Scanner inp = new Scanner(System.in);
//		System.out.println("Welcome to Tenant Management Application");
//		ApartmentModelBuilder aBuilder = new ApartmentModelBuilder();
//		CondoModelBuilder cBuilder = new CondoModelBuilder();
//		HouseModelBuilder hBuilder = new HouseModelBuilder();
//		LeaseModelBuilder lBuilder = new LeaseModelBuilder();
//		LeaseViewModelBuilder lViewBuilder = new LeaseViewModelBuilder();
//		PropertyModelBuilder pBuilder = new PropertyModelBuilder();
//		PropertyViewModelBuilder pViewBuilder = new PropertyViewModelBuilder();
//		RentModelBuilder rBuilder = new RentModelBuilder();
//		RentViewModelBuilder rViewBuilder = new RentViewModelBuilder();
//		TenantModelBuilder tBuilder = new TenantModelBuilder();
//		TenantViewBuilder tViewBuilder = new TenantViewBuilder();
//
//		// Property MVC Members
//		PropertyModel pModel = null;
//		PropertyView pView;
//		PropertyController pController = null;
//		ApartmentModel aModel;
//		CondoModel cModel;
//		HouseModel hModel;
//		TenantModel tModel;
//		TenantView tView;
//		TenantController tController;
//		RentModel rModel;
//		RentView rView;
//		RentController rController;
//		LeaseModel lModel;
//		LeaseView lView;
//		LeaseController lController;
//		int tenantId = 0;
//		String aptCivicAddress, condoStreetNumber, houseStreetNumber, streetName, city, postalCode, province, country,
//				firstName = null, lastName = null, eMail = null, leaseStartDate = null, leaseEndDate = null,
//				renovationUpdate, paymentDate = null;
//		int aptNumber, aptBathroomCount, aptBedroomCount, condoUnitNumber, propertyID = 0, tenantID = 0, rentOption,
//				leaseID = 0, option, propertyOption, rentAmount;
//		double aptSquareFootage;
//		boolean adminFlag = true, renovationFlag = false, leaseStartDateFlag = true, leaseEndDateFlag = true,
//				recordPaymentDateFlag = true, propertyIDFlag = true, tenantIDFlag = true, propertyVacantFlag;
//
//		while (adminFlag) {
//			try {
//				leaseStartDateFlag = true;
//				leaseEndDateFlag = true;
//				recordPaymentDateFlag = true;
//				propertyIDFlag = true;
//				tenantIDFlag = true;
//				System.out.println(
//						"Enter 1 to add property | 2 to add tenant | 3 to rent a unit | 4 to display properties | 5 to display tenants | 6 to display rented units | 7 to display vacant units | 8 to display all leases | 9 to track leases | 10 to record payment | 11 to track payments | 12 to Cancel Lease Agreement | 13 to update renovation status | 14 to exit application");
//				option = inp.nextInt();
//
//				switch (option) {
//				case 1:
//					System.out.println("Enter 1 for apartment | 2 for condo | 3 for house");
//					propertyOption = inp.nextInt();
//					switch (propertyOption) {
//					case 1:
//						try {
//							// Getting input necessary for apartment
//							System.out.println("Enter Property ID [in numbers]");
//							propertyID = inp.nextInt();
//							System.out.println("Enter apartment number");
//							aptNumber = inp.nextInt();
//							inp.nextLine();
//							System.out.println("Enter apartment civic address");
//							aptCivicAddress = inp.nextLine();
//							System.out.println("Enter street name");
//							streetName = inp.nextLine();
//							System.out.println("Enter city");
//							city = inp.nextLine();
//							System.out.println("Enter province");
//							province = inp.nextLine();
//							System.out.println("Enter country");
//							country = inp.nextLine();
//							System.out.println("Enter postal code");
//							postalCode = inp.nextLine();
//							System.out.println("Enter number of bedrooms in apartment");
//							aptBedroomCount = inp.nextInt();
//							System.out.println("Enter number of bathrooms in apartment");
//							aptBathroomCount = inp.nextInt();
//							System.out.println("Enter apartment square footage");
//							aptSquareFootage = inp.nextDouble();
//							System.out.println("Enter the rent of this property");
//							rentAmount = inp.nextInt();
//
//							// creating ApartmentModel using ApartmentBuilder
//							aModel = aBuilder.setPropertyID(propertyID).setaptNumber(aptNumber)
//									.setAptCivicAddress(aptCivicAddress).setStreetName(streetName).setCity(city)
//									.setProvince(province).setCountry(country).setPostalCode(postalCode)
//									.setAptBedroomCount(aptBedroomCount).setAptBathroomCount(aptBathroomCount)
//									.setAptSquareFootage(aptSquareFootage).setRentAmount(rentAmount).build();
//							// creating PropertyView using PropertyView
//							pView = pViewBuilder.build();
//							pController = new PropertyController(aModel, pView);
//							pController.savePropertyController(aModel); // saving property object in PropertyModel
//																		// through PropertyController
//							pController.addPropertyMessageController(
//									"Apartment of ID " + propertyID + " is added successfully"); // sending message to
//																									// PropertyView
//
//						} catch (Exception e) {
//							pController.addPropertyMessageController("Error in adding apartment " + e);
//
//						}
//						break;
//					case 2:
//						try {
//							// Getting input necessary for condo
//							System.out.println("Enter Property ID [in numbers]");
//							propertyID = inp.nextInt();
//							System.out.println("Enter condo unit number");
//							condoUnitNumber = inp.nextInt();
//							inp.nextLine();
//							System.out.println("Enter condo street number");
//							condoStreetNumber = inp.nextLine();
//							System.out.println("Enter street name");
//							streetName = inp.nextLine();
//							System.out.println("Enter city");
//							city = inp.nextLine();
//							System.out.println("Enter province");
//							province = inp.nextLine();
//							System.out.println("Enter country");
//							country = inp.nextLine();
//							System.out.println("Enter postal code");
//							postalCode = inp.nextLine();
//							System.out.println("Enter the rent of this property");
//							rentAmount = inp.nextInt();
//
//							// creating CondoModel using CondoBuilder
//							cModel = cBuilder.setPropertyID(propertyID).setCondoStreetNumber(condoStreetNumber)
//									.setCondoStreetNumber(condoStreetNumber).setStreetName(streetName).setCity(city)
//									.setProvince(province).setCountry(country).setPostalCode(postalCode)
//									.setRentAmount(rentAmount).build();
//							// creating PropertyView using PropertyView
//							pView = pViewBuilder.build();
//							pController = new PropertyController(cModel, pView);
//							pController.savePropertyController(cModel); // saving property object in PropertyModel
//																		// through PropertyController
//							pController.addPropertyMessageController(
//									"Condo of ID " + propertyID + " is added successfully"); // sending message to
//																								// PropertyView
//
//						} catch (Exception e) {
//							pController.addPropertyMessageController("Error in adding condo: " + e);
//
//						}
//						break;
//					case 3:
//						// Getting input necessary for house
//						try {
//							System.out.println("Enter Property ID [in numbers]");
//							propertyID = inp.nextInt();
//							inp.nextLine();
//							System.out.println("Enter house street number");
//							houseStreetNumber = inp.nextLine();
//							System.out.println("Enter street name");
//							streetName = inp.nextLine();
//							System.out.println("Enter city");
//							city = inp.nextLine();
//							System.out.println("Enter province");
//							province = inp.nextLine();
//							System.out.println("Enter country");
//							country = inp.nextLine();
//							System.out.println("Enter postal code");
//							postalCode = inp.nextLine();
//							System.out.println("Enter the rent of this property");
//							rentAmount = inp.nextInt();
//
//							// creating HouseModel using HouseBuilder
//							hModel = hBuilder.setPropertyID(propertyID).setHouseStreetNumber(houseStreetNumber)
//									.setStreetName(streetName).setCity(city).setProvince(province).setCountry(country)
//									.setPostalCode(postalCode).setRentAmount(rentAmount).build();
//							// creating PropertyView using PropertyView
//							pView = pViewBuilder.build();
//							pController = new PropertyController(hModel, pView);
//							pController.savePropertyController(hModel); // saving property object in PropertyModel
//																		// through PropertyController
//							pController.addPropertyMessageController(
//									"House of ID " + propertyID + " is added successfully"); // sending message to //
//																								// PropertyView
//
//						} catch (Exception e) {
//							pController.addPropertyMessageController("Error in adding house: " + e);
//
//						}
//						break;
//					default:
//						System.out.println("Enter valid option");
//					}
//					break;
//				case 2:
//					// Add Tenant
//					System.out.println("Enter Tenant ID");
//					tenantId = inp.nextInt();
//					inp.nextLine();
//					System.out.println("Enter first name of the Tenant");
//					firstName = inp.nextLine();
//					System.out.println("Enter last name of the Tenant");
//					lastName = inp.nextLine();
//					System.out.println("Enter Email of the tenant");
//					eMail = inp.nextLine();
//					String regex = "^(.+)@(.+)$";
//					Pattern pattern = Pattern.compile(regex);
//					Matcher matcher = pattern.matcher(eMail);
//					// check
//					while (!matcher.matches()) {
//						System.out.println("Invalid email..... Please enter a valid email address");
//						eMail = inp.nextLine();
//						matcher = pattern.matcher(eMail);
//					}
//
//					// Creating TenantModel using TenantBuiler
//					tModel = tBuilder.setTenantID(tenantId).setFirstName(firstName).setLastName(lastName)
//							.setEmail(eMail).build();
//					// Creating WaitlistView using WaitListViewBuilder
//					tView = tViewBuilder.build();
//					tController = new TenantController(tModel, tView);
//					tController.saveTenantObject(tenantId, tModel);
//					tController.addTenantMessage("Tenant " + tenantId + " Added successfully");
//					break;
//				case 3:
//					// Renting a unit
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pController = new PropertyController(pModel, pView);
//					// Creating TenantModel and TenantView using Builder
//					tModel = tBuilder.setTenantID(tenantId).setFirstName(firstName).setLastName(lastName)
//							.setEmail(eMail).build();
//					tView = tViewBuilder.build();
//					tController = new TenantController(tModel, tView);
//					while (propertyIDFlag) {
//						System.out.println("Enter Property ID");
//						propertyID = inp.nextInt();
//						if (pController.getPropertyController(propertyID) == null) {
//							System.out.println(
//									"Sorry there is no property registered in this ID, try entering a valid Property ID");
//						} else {
//							propertyIDFlag = false;
//						}
//					}
//					propertyVacantFlag = pController.getPropertyController(propertyID).isVacant ? true : false;
//					if (propertyVacantFlag == false) {
//						System.out.println(
//								"Property is currently not vacant, kindly provide your details. Will contact you once it gets vacant");
//					}
//					if (propertyVacantFlag == true) {
//						System.out.println("Enter Lease ID");
//						leaseID = inp.nextInt();
//					}
//					while (tenantIDFlag) {
//						System.out.println("Enter Tenant ID");
//						tenantID = inp.nextInt();
//						if (tController.getTenant(tenantID) == null) {
//							System.out.println(
//									"Sorry, there is no tenant regsitered in this ID, try entering a valid Tenant ID");
//						} else {
//							tenantIDFlag = false;
//						}
//					}
//
//					inp.nextLine();
//					// Lease Start Date Validity Check
//					if (propertyVacantFlag == true) {
//						while (leaseStartDateFlag) {
//							System.out.println("Enter Lease Start Date in DD/MM/YYYY format");
//							leaseStartDate = inp.nextLine();
//							String dateValidityCheck = Tenant_Manangement_Main_Class.checkDateValidity(leaseStartDate);
//							if (dateValidityCheck == "Invalid") {
//								System.out.println("Enter a valid date");
//
//							} else {
//								leaseStartDateFlag = false;
//							}
//						}
//						// Lease End Date Validity Check
//						while (leaseEndDateFlag) {
//							System.out.println("Enter Lease End Date in DD/MM/YYYY format");
//							leaseEndDate = inp.nextLine();
//							String dateValidityCheck = Tenant_Manangement_Main_Class.checkDateValidity(leaseEndDate);
//							if (dateValidityCheck == "Invalid") {
//								System.out.println("Enter a valid date");
//
//							} else {
//								leaseEndDateFlag = false;
//							}
//						}
//					}
//
//					pController.rentPropertyController(leaseID, propertyID, tenantID, leaseStartDate, leaseEndDate);
//					break;
//
//				case 4:
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pController = new PropertyController(pModel, pView);
//					pController.displayPropertyController();
//					break;
//
//				case 5:
//					// Displaying Tenants
//					// Building TenantModel and TenantView using builder
//					tModel = tBuilder.build();
//					tView = tViewBuilder.build();
//					tController = new TenantController(tModel, tView);
//					tController.getTenantList();
//					break;
//
//				case 6:
//					// Display rented propertied
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pController = new PropertyController(pModel, pView);
//					pController.displayRentedUnitsController();
//					break;
//
//				case 7:
//					// Display vacant propertied
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pController = new PropertyController(pModel, pView);
//					pController.displayVacantUnitsController();
//					break;
//
//				case 8:
//					// Display All Lease
//					// Building PropertyModel and PropertyView using builder
//					lModel = lBuilder.build();
//					lView = lViewBuilder.build();
//					lController = new LeaseController(lModel, lView);
//					lController.updateLeaseView();
//					break;
//
//				case 9:
//					// Track Lease
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pController = new PropertyController(pModel, pView);
//					while (propertyIDFlag) {
//						System.out.println("Enter Property ID to track the lease");
//						propertyID = inp.nextInt();
//						if (pController.getPropertyController(propertyID) == null) {
//							System.out.println(
//									"Sorry there is no property registered in this ID, try entering a valid Property ID");
//						} else {
//							propertyIDFlag = false;
//						}
//					}
//					// Building PropertyModel and PropertyView using builder
//					lModel = lBuilder.build();
//					lView = lViewBuilder.build();
//					lController = new LeaseController(lModel, lView);
//					lController.getLeaseDetailsController(propertyID);
//					break;
//
//				case 10:
//					// Record Payment
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pController = new PropertyController(pModel, pView);
//					// Creating TenantModel and TenantView using Builder
//					tModel = tBuilder.setTenantID(tenantId).setFirstName(firstName).setLastName(lastName)
//							.setEmail(eMail).build();
//					tView = tViewBuilder.build();
//					tController = new TenantController(tModel, tView);
//					while (propertyIDFlag) {
//						System.out.println("Enter the property ID");
//						propertyID = inp.nextInt();
//						if (pController.getPropertyController(propertyID) == null) {
//							System.out.println(
//									"Sorry there is no property registered in this ID, try entering a valid Property ID");
//						} else {
//							propertyIDFlag = false;
//						}
//					}
//					while (tenantIDFlag) {
//						System.out.println("Enter Tenant ID");
//						tenantID = inp.nextInt();
//						if (tController.getTenant(tenantID) == null) {
//							System.out.println(
//									"Sorry, there is no tenant regsitered in this ID, try entering a valid Tenant ID");
//						} else {
//							tenantIDFlag = false;
//						}
//					}
//					inp.nextLine();
//					// Record Payment Date Validity Check
//					while (recordPaymentDateFlag) {
//						System.out.println("Enter the date of payment in DD/MM/YYYY format");
//						paymentDate = inp.nextLine();
//						String dateValidityCheck = Tenant_Manangement_Main_Class.checkDateValidity(paymentDate);
//						if (dateValidityCheck == "Invalid") {
//							System.out.println("Enter a valid date");
//
//						} else {
//							recordPaymentDateFlag = false;
//						}
//					}
//					System.out.println("Enter rent amount");
//					rentAmount = inp.nextInt();
//					// Building RentModel and RentView using builder
//					rModel = rBuilder.build();
//					rView = rViewBuilder.build();
//					rController = new RentController(rModel, rView);
//					rController.addRentPayment(propertyID, tenantID, paymentDate, rentAmount);
//					break;
//
//				case 11:
//					// Track Payments
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pController = new PropertyController(pModel, pView);
//					while (propertyIDFlag) {
//						System.out.println("Enter Property ID to track payment");
//						propertyID = inp.nextInt();
//						if (pController.getPropertyController(propertyID) == null) {
//							System.out.println(
//									"Sorry there is no property registered in this ID, try entering a valid Property ID");
//						} else {
//							propertyIDFlag = false;
//						}
//					}
//					// Building RentModel and RentView using builder
//					rModel = rBuilder.build();
//					rView = rViewBuilder.build();
//					rController = new RentController(rModel, rView);
//					rController.checkRentStatusController(propertyID);
//					break;
//
//				case 12:
//					// Cancel Lease
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pController = new PropertyController(pModel, pView);
//					// Performing Waitlist update functionality
//					WaitlistModel wModel = new WaitlistModel();
//					WaitlistView wView = new WaitlistView();
//					WaitlistController wController = new WaitlistController(wModel, wView);
//					while (propertyIDFlag) {
//						System.out.println("Enter Property ID to cancel the lease");
//						propertyID = inp.nextInt();
//						if (pController.getPropertyController(propertyID) == null) {
//							System.out.println(
//									"Sorry there is no property registered in this ID, try entering a valid Property ID");
//						} else {
//							propertyIDFlag = false;
//						}
//					}
//					inp.nextLine();
//					System.out.println("Enter Yes for renovation needed or No if renovation needed");
//					renovationUpdate = inp.nextLine();
//					if (renovationUpdate.equalsIgnoreCase("Yes") || renovationUpdate.equalsIgnoreCase("Y")) {
//						renovationFlag = true;
//					} else if (renovationUpdate.equalsIgnoreCase("No") || renovationUpdate.equalsIgnoreCase("Y")) {
//						renovationFlag = false;
//					}
//
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pModel.addObserver(wView);
//					pController = new PropertyController(pModel, pView);
//					pController.cancelLeaseController(propertyID, renovationFlag);
//					break;
//
//				case 13:
//					// Update renovation status
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pController = new PropertyController(pModel, pView);
//					while (propertyIDFlag) {
//						System.out.println("Enter Property ID update renovation status");
//						propertyID = inp.nextInt();
//						if (pController.getPropertyController(propertyID) == null) {
//							System.out.println(
//									"Sorry there is no property registered in this ID, try entering a valid Property ID");
//						} else {
//							propertyIDFlag = false;
//						}
//					}
//					System.out.println("Enter Yes for renovation needed or No if renovation needed");
//					inp.nextLine();
//					renovationUpdate = inp.nextLine();
//					if (renovationUpdate.equalsIgnoreCase("Yes") || renovationUpdate.equalsIgnoreCase("Y")) {
//						renovationFlag = true;
//					} else if (renovationUpdate.equalsIgnoreCase("No") || renovationUpdate.equalsIgnoreCase("Y")) {
//						renovationFlag = false;
//					}
//					// Building PropertyModel and PropertyView using builder
//					pModel = pBuilder.build();
//					pView = pViewBuilder.build();
//					pController = new PropertyController(pModel, pView);
//					pController.updateRenovationStatus(propertyID, renovationFlag);
//					break;
//
//				case 14:
//					adminFlag = false;
//					System.out.println("Application closed successfully");
//					break;
//				default:
//					System.out.println("Enter valid option");
//				}
//			} catch (Exception e) {
//				System.out.println("Error occured: " + e);
//				inp.next();
//			}
//		}
//
//		inp.close();
//	}

	

}
