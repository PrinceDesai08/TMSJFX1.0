package main.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

import main.controller.WaitlistController;
import main.model.PropertyModel;
import main.model.TenantModel;
import main.model.WaitlistModel;

public class WaitlistView implements Observer {
	  // "displayAddPropertyResult()" will display the message sent by PropertyConroller after adding the property into PropertyModel
	  public void displayAddWaitListResult(String message) {
		  System.out.println(message);
	  }
	
      public void displayWaitList(String message) {
    	  System.out.println(message);
      }
      public void notifyTenants(int propertyid,ArrayList<TenantModel>notifyTenants)
      {
    	  //WaitlistController wLC=new WaitlistController();
    	  //ArrayList<TenantModel>tenantswailtlisted=wLC.notifyTenants(propertyid);
    	  if(notifyTenants.isEmpty())
    	  {
    		  System.out.println("No tenants found for the particular property id: - "+propertyid);
    	  }
    	  else
    	  {
    		  for (TenantModel tenant : notifyTenants) 
    		  {
				System.out.println("Dear "+tenant.getName()+" the property you were looking for is available. Kindly contact the admin before its gone!!!!");
			}
    	  }
      }

	@Override
	public void update(Observable o, Object arg) {
		
		ArrayList<TenantModel> notifyTenants = new ArrayList<TenantModel>();
		int propertyID=0;
		if(arg instanceof Integer) {
			propertyID = Integer.parseInt(arg.toString());
			System.out.println("No tenants found in the waitlist for the property id -  "+propertyID);
		}
		else if(arg instanceof ArrayList) {
             
             notifyTenants = (ArrayList<TenantModel>) arg;
           //WaitlistController wLC=new WaitlistController();
         	  //ArrayList<TenantModel>tenantswailtlisted=wLC.notifyTenants(propertyid);
         	  
         		  for (TenantModel tenant : notifyTenants) 
         		  {
       				System.out.println("Dear "+tenant.getName()+", the property you were looking for is available. Kindly contact the admin before its gone!!!!");
       			}
         	  
		}
		
	  
		
	}
}